document.getElementById ('androidbtn').addEventListener('click', setAndroid);
document.getElementById ('applebtn').addEventListener('click', setApple);
document.getElementById ('explorebtn').addEventListener('click', setPage);







// Event Functions
function setAndroid() {
    document.getElementById ('img').src = 'images/Android-logo.jpg';
    document.getElementById ('the-link').href = 'https://www.android.com/';
    document.getElementById ('the-link').style.backgroundColor = '#a4c93b';
    document.body.style.backgroundColor = '#a4c93b';
    document.getElementById ('the-link').innerHTML = 'Android Home'
    document.getElementById ('Back-Link').innerHTML = 'Go Back'
}

function setApple() {
    document.getElementById ('img').src = 'images/Apple-logo.jpg';
    document.getElementById ('the-link').href = 'https://www.apple.com/';
    document.getElementById ('the-link').style.backgroundColor = '#b6bcca';
    document.body.style.backgroundColor = '#b6bcca';
    document.getElementById ('the-link').innerHTML = 'Apple Home'
    document.getElementById ('Back-Link').innerHTML = 'Go Back'
}